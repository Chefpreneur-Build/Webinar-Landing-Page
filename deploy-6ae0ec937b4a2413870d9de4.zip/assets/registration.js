const dialog = document.querySelector('#register');
const form = document.querySelector('#signup-form');
let opener;
let previousOverflow;
let countdownTimer;

function updateCountdown() {
  const remaining = Math.max(0, Math.floor((Date.parse('2026-11-09T13:00:00-05:00') - Date.now()) / 1000));
  const units = { days: Math.floor(remaining / 86400), hours: Math.floor(remaining / 3600) % 24, minutes: Math.floor(remaining / 60) % 60, seconds: remaining % 60 };
  for (const [unit, value] of Object.entries(units)) {
    dialog.querySelector(`[data-count="${unit}"]`).textContent = String(value).padStart(2, '0');
  }
  if (!remaining) dialog.querySelector('.signup-countdown > p').textContent = 'THE WORKSHOP HAS STARTED';
}

document.addEventListener('click', (event) => {
  const trigger = event.target.closest('a[href="#register"]');
  if (!trigger) return;
  event.preventDefault();
  if (dialog.open) return;
  opener = trigger;
  previousOverflow = document.body.style.overflow;
  document.body.style.overflow = 'hidden';
  updateCountdown();
  countdownTimer = setInterval(updateCountdown, 1000);
  dialog.showModal();
});

dialog.querySelector('.signup-close').addEventListener('click', () => dialog.close());
dialog.querySelector('.signup-done').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', (event) => {
  if (event.target !== dialog) return;
  const bounds = dialog.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close();
});
dialog.addEventListener('close', () => {
  clearInterval(countdownTimer);
  document.body.style.overflow = previousOverflow ?? '';
  opener?.focus();
});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = form.querySelector('[type="submit"]');
  const error = document.querySelector('#signup-error');
  if (button.disabled) return;
  error.hidden = true;
  button.disabled = true;
  button.setAttribute('aria-busy', 'true');
  const label = button.innerHTML;
  button.textContent = 'Reserving your seat…';
  try {
    const response = await fetch('/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(new FormData(form)).toString(),
    });
    if (!response.ok) throw new Error('Registration failed');
    form.hidden = true;
    const success = document.querySelector('#signup-success');
    success.hidden = false;
    success.querySelector('button').focus();
  } catch {
    error.textContent = 'We couldn’t save your registration. Please try again.';
    error.hidden = false;
  } finally {
    button.disabled = false;
    button.removeAttribute('aria-busy');
    button.innerHTML = label;
  }
});
